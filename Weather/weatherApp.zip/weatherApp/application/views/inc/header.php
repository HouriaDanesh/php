<head>
    <meta charset="utf-8">

    <base href="<?= base_url(); ?>" />
    <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>

    <script src="<?= base_url(); ?>js/find_city.js"></script>
    <script src="<?= base_url(); ?>js/from_location.js"></script>
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>css/style.css"/>
    <link rel="stylesheet" href="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.indigo-pink.min.css">
    <script src="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>